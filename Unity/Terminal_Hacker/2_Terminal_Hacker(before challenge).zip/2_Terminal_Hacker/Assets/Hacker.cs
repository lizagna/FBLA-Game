﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hacker : MonoBehaviour {

    // Game state
    int level; // member variable

    enum Screen {MainMenu, Password, Win}
    Screen currentScreen;


    // Use this for initialization
    void Start() {
        ShowMainMenu();
    }

    void ShowMainMenu() {
        currentScreen = Screen.MainMenu;
        Terminal.ClearScreen();
        Terminal.WriteLine("What would you like to hack into?");
        Terminal.WriteLine("Press 1 for Schoology");
        Terminal.WriteLine("Press 2 for my Amazon account");
        Terminal.WriteLine("Press 3 for browser history");
        Terminal.WriteLine("Enter you selection: ");
    }

    // OnUserInput should only decides how to handle input, NOT do something
    void OnUserInput(string input)
    {
        if (input == "menu") // we can always go direct to main menu
        {
            ShowMainMenu();
        }
        else if (currentScreen == Screen.MainMenu)
        {
            RunMainMenu(input);
        }        

    }

    void RunMainMenu(string input)
    {
        if (input == "1")
        {
            level = 1;
            StartGame(1);
        }
        else if (input == "2")
        {
            level = 2;
            StartGame(2);
        }
        else if (input == "3")
        {
            level = 3;
            StartGame(3);
        }
        else
        {
            Terminal.WriteLine("ERROR ERROR INTRUDER ALERT TERMINAL.EXE HAS FAILED");
        }
    }

    void StartGame(int level)
    {
        currentScreen = Screen.Password;
        Terminal.WriteLine("You have chosen " + level);
        Terminal.WriteLine("Please enter your password: ");

    }

}
